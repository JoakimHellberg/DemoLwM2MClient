#!/bin/bash
cd /opt/LWM2MClient

java -jar /opt/LWM2MClient/SimpleLwm2mClient-0.0.1-SNAPSHOT-jar-with-dependencies